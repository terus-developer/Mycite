<?php

/**
* Русский языковой файл.
* Содержит текстовки шаблона.
*/
return array(
	'footer_menu_user_profile' => 'Мой профиль',
	'footer_menu_user_quest_title' => 'Вы можете',
	'footer_menu_navigate_title' => 'Разделы',
	'footer_menu_project_title' => 'LiveStreet CMS',
	'footer_menu_project_about' => 'О проекте',
	'footer_menu_project_contact' => 'Контакты',
	'footer_menu_project_advert' => 'Реклама',
	'footer_menu_project_help' => 'Помощь',

	'blog_leave' => 'Покинуть блог',
	'blog_join' => 'Вступить в блог',
	'blog_expand_info' => 'О блоге',
	'blog_fold_info' => 'Свернуть',
	
	'profile_about_empty' => 'Пока ничего не известно...',
	'profile_about_edit' => 'Редактировать',
	'header_or' => 'или',
	'design_by' => 'Дизайн — веб-студия'
);