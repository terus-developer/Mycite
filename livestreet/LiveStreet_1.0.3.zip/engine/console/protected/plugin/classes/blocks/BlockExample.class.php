<?php

class PluginExample_BlockExample extends Block {
    public function Exec() {

    }
}
?>
