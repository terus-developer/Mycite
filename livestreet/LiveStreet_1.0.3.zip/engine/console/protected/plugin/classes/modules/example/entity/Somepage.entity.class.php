<?php

class PluginExample_ModuleExample_EntityExample extends Entity
{

}

?>
